package com.svalero.programacionEVA2.dao;

import com.svalero.programacionEVA2.model.Car;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CarDao {

    private final Connection connection;

    public CarDao(Connection connection) {
        this.connection = connection;
    }

    public List<Car> getAll() throws SQLException {
        String sql = "SELECT * FROM vehicle";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet result = statement.executeQuery();

        List<Car> carList = new ArrayList<>();
        while (result.next()) {
            Car car = extractCar(result);
            carList.add(car);
        }

        statement.close();
        return carList;
    }

    public List<Car> getPaginated(int limit, int offset) throws SQLException {
        String sql = "SELECT * FROM vehicle LIMIT ? OFFSET ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, limit);
        statement.setInt(2, offset);
        ResultSet result = statement.executeQuery();

        List<Car> carList = new ArrayList<>();
        while (result.next()) {
            carList.add(extractCar(result));
        }

        statement.close();
        return carList;
    }

    public int countAll() throws SQLException {
        String sql = "SELECT COUNT(*) FROM vehicle";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet result = statement.executeQuery();
        int count = 0;
        if (result.next()) {
            count = result.getInt(1);
        }
        statement.close();
        return count;
    }

    public List<Car> searchByNamePaginated(String keyword, int limit, int offset) throws SQLException {
        String sql = "SELECT * FROM vehicle WHERE brand LIKE ? OR model LIKE ? LIMIT ? OFFSET ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        String pattern = "%" + keyword + "%";
        statement.setString(1, pattern);
        statement.setString(2, pattern);
        statement.setInt(3, limit);
        statement.setInt(4, offset);
        ResultSet result = statement.executeQuery();

        List<Car> carList = new ArrayList<>();
        while (result.next()) {
            carList.add(extractCar(result));
        }

        statement.close();
        return carList;
    }

    public int countSearchByName(String keyword) throws SQLException {
        String sql = "SELECT COUNT(*) FROM vehicle WHERE brand LIKE ? OR model LIKE ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        String pattern = "%" + keyword + "%";
        statement.setString(1, pattern);
        statement.setString(2, pattern);
        ResultSet result = statement.executeQuery();
        int count = 0;
        if (result.next()) {
            count = result.getInt(1);
        }
        statement.close();
        return count;
    }

    public Car getById(int id) throws SQLException {
        String sql = "SELECT * FROM vehicle WHERE vehicle_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet result = statement.executeQuery();

        Car car = null;
        if (result.next()) {
            car = extractCar(result);
        }

        statement.close();
        return car;
    }

    public boolean add(Car car) throws SQLException {
        String sql = "INSERT INTO vehicle (brand, model, year, sale_price, rental_price_per_day, is_available, image, description) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, car.getBrand());
        statement.setString(2, car.getModel());
        statement.setInt(3, car.getYear());
        statement.setDouble(4, car.getSalePrice());
        statement.setDouble(5, car.getRentalPricePerDay());
        statement.setBoolean(6, car.isAvailable());
        statement.setString(7, car.getImage());
        statement.setString(8, car.getDescription());

        int rowsAffected = statement.executeUpdate();
        statement.close();
        return rowsAffected > 0;
    }

    public boolean update(Car car) throws SQLException {
        String sql = "UPDATE vehicle SET brand = ?, model = ?, year = ?, sale_price = ?, rental_price_per_day = ?, is_available = ?, image = ?, description = ? WHERE vehicle_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, car.getBrand());
        statement.setString(2, car.getModel());
        statement.setInt(3, car.getYear());
        statement.setDouble(4, car.getSalePrice());
        statement.setDouble(5, car.getRentalPricePerDay());
        statement.setBoolean(6, car.isAvailable());
        statement.setString(7, car.getImage());
        statement.setString(8, car.getDescription());
        statement.setInt(9, car.getId());

        int rowsAffected = statement.executeUpdate();
        statement.close();
        return rowsAffected > 0;
    }

    public boolean deleteById(int id) throws SQLException {
        String sql = "DELETE FROM vehicle WHERE vehicle_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        int rows = statement.executeUpdate();
        statement.close();
        return rows > 0;
    }

    private Car extractCar(ResultSet result) throws SQLException {
        Car car = new Car();
        car.setId(result.getInt("vehicle_id"));
        car.setBrand(result.getString("brand"));
        car.setModel(result.getString("model"));
        car.setYear(result.getInt("year"));
        car.setSalePrice(result.getDouble("sale_price"));
        car.setRentalPricePerDay(result.getDouble("rental_price_per_day"));
        car.setAvailable(result.getBoolean("is_available"));
        car.setImage(result.getString("image"));
        car.setDescription(result.getString("description"));
        return car;
    }
}
