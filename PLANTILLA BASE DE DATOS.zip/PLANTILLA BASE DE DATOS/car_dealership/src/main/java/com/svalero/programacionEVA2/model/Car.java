package com.svalero.programacionEVA2.model;

import lombok.Data;

@Data
public class Car {
    private int id;
    private String image;
    private String description;
    private String brand;
    private String model;
    private int year;
    private double salePrice;
    private double rentalPricePerDay;
    private boolean available;
}

